README - Assignment 2 Pete Solution
v1.2
10/13/2019


Keep these files in the provided directories.

Note: You will need to have a running PRSServer to use the FTServer and FTClient

Run the PRSServer in one cmd prompt
Run the FTServer in a second cmd prompt
Run the FTClient in a third cmd prompt

The PRSServer and FTServer both accept command line arguments, but will work on a single machine with the default arguments.

The FTClient must be passed at least the -d argument to get the named directory. For example...
	FTClient -d foo
	FTClient -d bar

Try PRSServer -help, FTServer -help and FTClient -help to see the usage statements.
