#ifndef BINARYSTREE_H
#define BINARYSTREE_H
#include "TNode.h"

template<typename T>
class BinarySTree
{
public:
	BinarySTree();
	BinarySTree(const BinarySTree & copy);
	~BinarySTree();
	BinarySTree & operator =(const BinarySTree & rhs);
	void Purge();
	void Height();
	void Insert(T data);
	void DeleteFind(T data);
	void DeleteFound(T data, TNode<T> * todel);
	void BreadthFirst(void Visit(TNode<T>*));
	void PreOrder(void Visit(TNode<T>*));
	void PostOrder(void Visit(TNode<T>*));
	void InOrder(void Visit(TNode<T>*));
private:
	TNode<T>* m_head;
};

template<typename T>
BinarySTree<T>::BinarySTree(): m_head(nullptr)
{
}

template<typename T>
BinarySTree<T>::BinarySTree(const BinarySTree & copy): m_head(copy.m_head)
{
	if (m_head != nullptr)
	{
		TNode<T> *leftp = copy.m_head->GetLeft();
		TNode<T> *rightp = copy.m_head->GetRight();
	}
}

template<typename T>
BinarySTree<T>::~BinarySTree()
{
	Purge();
	m_head = nullptr;
}

template<typename T>
BinarySTree & BinarySTree<T>::operator=(const BinarySTree & rhs)
{
	if (this != &rhs)
	{
		Purge();
		if (rhs.m_head != nullptr)
		{

		}
	}
	return *this;
}

#endif

