#ifndef ARRAY2D_H
#define ARRAY2D_H
#include "Array.h"
#include "Row.h"
#include "Exception.h"
#include <iostream>

template<typename T>
class Array2D
{
public:
	Array2D();
	Array2D(int row, int col = 0);
	Array2D(const Array2D & copy);
	~Array2D();
	Array2D & operator =(const Array2D & rhs);
	Row<T> operator[](int index); //non const objects will use this
	const Row<T> operator[](int index) const; //only can be called by const objects
	int GetRow() const;
	void SetRows(int row);
	int GetColumns() const;
	void SetColumns(int col);
	T& Select(int row, int column); //non const objects will use this
	const T& Select(int row, int column) const; //only can be called by const objects
private: //making new select, array2D op[] and row op[] const and const methods will allow const methods to get the data, but not change the data
	Array<T> m_array;
	int m_row;
	int m_col;
};


template<typename T>
Array2D<T>::Array2D():m_array(0), m_row(0), m_col(0)
{
}

template<typename T>
Array2D<T>::Array2D(int row, int col) : m_array(col*row), m_row(row), m_col(col)
{
}

template<typename T>
Array2D<T>::Array2D(const Array2D & copy) : m_array(copy.m_array), m_row(copy.m_row), m_col(copy.m_col)
{
}

template<typename T>
Array2D<T>::~Array2D()
{
	m_row = 0;
	m_col = 0;
}

template<typename T>
Array2D<T> & Array2D<T>::operator=(const Array2D & rhs)
{
	if (this != &rhs)
	{
		m_array = rhs.m_array;
		m_col = rhs.m_col;
		m_row = rhs.m_row;
	}
	return *this;
}

template<typename T>
Row<T> Array2D<T>::operator[](int index)
{
	if (index > m_row || index < 0)
	{
		throw Exception("Out of bounds: Rows");
	}
	Row<T> temp(*this, index);
	return temp;
}

template<typename T>
const Row<T> Array2D<T>::operator[](int index) const
{
	if (index > m_row || index < 0)
	{
		throw Exception("Out of bounds: Rows");
	}
	Row<T> temp(*this, index);
	return temp;
}

template<typename T>
int Array2D<T>::GetRow() const
{
	return m_row;
}

template<typename T>
void Array2D<T>::SetRows(int row)
{
	m_row = row; //similar to setlength of array as all we do is add data to the end of the array
	m_array.SetLength(m_row * m_col);
}

template<typename T>
int Array2D<T>::GetColumns() const
{
	return m_col;
}

template<typename T> 
void Array2D<T>::SetColumns(int col) //add data between two existing data elements 0-4 are the same but 5-9 are new and 10-14 are the continuation of 0-4
{									 // example data array 1,2,3,4,5,6,7,8,9,10 example what new data array should be 1,2,3,4,5,?,?,?,?,?,6,7,8,9,10
	Array<T> temp(m_row*col);
	for (int i(0); i < m_row; i++)
	{
		for (int j(0); j < m_col && j < col; j++) //whichever is smaller m_col or col will copy the right amount into the new array
		{
			temp[i*col + j] = m_array[i*m_col + j]; //multiplying i*col in temps subscript is to make sure the right row will be selected if the array is smaller or larger
		}
	}
	m_array = temp;
	m_col = col;
}

template<typename T>
T & Array2D<T>::Select(int row, int column)
{
	if (column > m_col || column < 0)
	{
		throw Exception("Out of bounds: Columns");
	}
	return m_array[row * m_col + column];
}

template<typename T>
const T & Array2D<T>::Select(int row, int column) const
{
	if (column > m_col || column < 0)
	{
		throw Exception("Out of bounds: Columns");
	}
	return m_array[row * m_col + column];
}

#endif