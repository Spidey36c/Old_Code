#ifndef ARRAY2D_H
#define ARRAY2D_H
#include "Exception.h"
#include "Row.h"

template<typename T>
class Array2D
{
public:
	Array2D();
	Array2D(int row, int col = 0);
	Array2D(const Array2D & copy);
	~Array2D();
	Array2D & operator =(const Array2D & rhs);
	Row<T> operator[](int index) const;
	int GetRow() const;
	void SetRows(int rows);
	int GetColumns() const;
	void SetColumns(int columns);
	T & Select(int row, int column) const;
private:
	T** m_array;
	int m_row;
	int m_col;
};

template<typename T>
Array2D<T>::Array2D(): m_array(nullptr), m_row(0), m_col(0)
{
}

template<typename T>
Array2D<T>::Array2D(int row, int col): m_row(row), m_col(col)
{
	m_array = new T*[m_row];
	for (int i(0); i < m_row; i++)
	{
		m_array[i] = new T[m_col];
	}
}

template<typename T>
Array2D<T>::Array2D(const Array2D & copy): m_row(copy.m_row), m_col(copy.m_col)
{
	m_array = new T *[m_row];
	for (int i(0); i < m_row; i++)
	{
		m_array[i] = new T[m_col];
	}

	for (int i(0); i < m_row; i++)
	{
		for (int j(0); j < m_col; j++)
		{
			m_array[i][j] = copy.m_array[i][j];
		}
	}
}

template<typename T>
Array2D<T>::~Array2D()
{
	for (int i(0); i < m_row; i++)
	{
		delete[] m_array[i];
	}
	delete[] m_array;
	m_array = nullptr;
	m_row = 0;
	m_col = 0;
}

template<typename T>
Array2D<T> & Array2D<T>::operator=(const Array2D & rhs)
{
	if (this != &rhs)
	{
		for (int i(0); i < m_row; i++)
		{
			delete[] m_array[i];
		}
		delete[] m_array;
		m_array = nullptr;

		m_array = new T *[rhs.m_row];
		for (int i(0); i < rhs.m_row; i++)
		{
			m_array[i] = new T[rhs.m_col];
		}

		for (int i(0); i < rhs.m_row; i++)
		{
			for (int j(0); j < rhs.m_col; j++)
			{
				m_array[i][j] = rhs.m_array[i][j];
			}
		}
		m_row = rhs.m_row;
		m_col = rhs.m_col;
	}

	return *this;
}

template<typename T>
Row<T> Array2D<T>::operator[](int index) const
{
	if (index < 0 || index > m_row)
	{
		throw Exception("Out of bounds: Rows");
	}
	Row<T> temp(const_cast<Array2D&>(*this), index);
	return temp;
}

template<typename T>
int Array2D<T>::GetRow() const
{
	return m_row;
}

template<typename T>
void Array2D<T>::SetRows(int rows)
{
	T** temp = new T*[rows];
	for (int i(0); i < rows; i++)
	{
		temp[i] = new T[m_col];
	}

	for (int i(0); i < m_row && i < rows; i++)
	{
		for (int j(0); j < m_col; j++)
		{
			temp[i][j] = m_array[i][j];
		}
	}

	for (int i(0); i < m_row; i++)
	{
		delete[] m_array[i];
	}
	delete[] m_array;
	m_array = nullptr;
	m_array = temp;
	m_row = rows;
}

template<typename T>
int Array2D<T>::GetColumns() const
{
	return m_col;
}

template<typename T>
void Array2D<T>::SetColumns(int columns)
{
	T** temp = new T*[m_row];
	for (int i(0); i < m_row; i++)
	{
		temp[i] = new T[columns];
	}

	for (int i(0); i < m_row; i++)
	{
		for (int j(0); j < m_col && j < columns; j++)
		{
			temp[i][j] = m_array[i][j];
		}
	}

	for (int i(0); i < m_row; i++)
	{
		delete[] m_array[i];
	}
	delete[] m_array;
	m_array = nullptr;
	m_array = temp;
	m_col = columns;

}

template<typename T>
T & Array2D<T>::Select(int row, int column) const
{
	if (column > m_col || column < 0)
	{
		throw Exception("Out of bounds: Columns");
	}
	return m_array[row][column];
}


#endif

