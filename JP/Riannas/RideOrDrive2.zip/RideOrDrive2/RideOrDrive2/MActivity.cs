﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace RideOrDrive2
{
    [Activity(Label = "MActivity")]
    public class MActivity : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.Map);

            var RiderButton = FindViewById<Button>(Resource.Id.RiderButton);

            RiderButton.Click += (s, e) =>
            {
                Intent nextActivity = new Intent(this, typeof(RActivity));
                StartActivity(nextActivity);
            };

            var DriverButton = FindViewById<Button>(Resource.Id.DriverButton);

            DriverButton.Click += (s, e) =>
            {
                Intent nextActivity = new Intent(this, typeof(MainActivity));
                StartActivity(nextActivity);
            };
        }
    }
}