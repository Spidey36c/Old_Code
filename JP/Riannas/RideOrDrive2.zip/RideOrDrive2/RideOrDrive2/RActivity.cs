﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace RideOrDrive2
{
    [Activity(Label = "RActivity")]

    public class RActivity : Activity
    {

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.Rider);

            var DriverButton = FindViewById<Button>(Resource.Id.DriverButton);

            DriverButton.Click += (s, e) =>
            {
                Intent nextActivity = new Intent(this, typeof(MainActivity));
                StartActivity(nextActivity);
            };

            var MapButton = FindViewById<Button>(Resource.Id.MapButton);

            MapButton.Click += (s, e) =>
            {
                Intent nextActivity = new Intent(this, typeof(MActivity));
                StartActivity(nextActivity);
            };

            var spinner = FindViewById<Spinner>(Resource.Id.TripDropdown);

            //   Trip.Click += (s, e) =>
            {
               // MySqlDataReader rdr;
                String str = "server=97.94.243.139;user id=monty;database=5GLTE;password=9hZh4S7t";
                String query = "select * from Trips";
                //String[] Cols = null;
                // Array[] Rows;

                ArrayAdapter arrayAdapter = new ArrayAdapter<string>(this, Android.Resource.Layout.SimpleSpinnerItem);


                var conn = new MySqlConnection(str);
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn);
                {
                    ArrayList items = new ArrayList();
                    //  var qry = "SELECT FileName FROM FileStore";
                    MySqlCommandBuilder cmd = new MySqlCommandBuilder(adapter);
                     //conn.Open();
                    //rdr = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    // spinner. = dt;
                    //if (dt.)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            string Cols = "";
                            Cols += (row["StartLocation"].ToString());
                           // Cols.Append(row["StartLocation"].ToString());
                            Cols += (" to ");
                            Cols += (row["EndLocation"].ToString());
                            arrayAdapter.Add(Cols);
                            

                        }
                    }
                   // ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, Android.Resource.Layout.SimpleSpinnerItem, items);
                    spinner.Adapter = (arrayAdapter);
                    conn.Close();
                }


                //  spinner.Adapter = (arrayAdapter);

                //Use must initialize

                // Spinner spinner = (Spinner)findViewById(R.id.spinner1);


                //  using
                //(var adapter = new ArrayAdapter<string>(this, Android.Resource.Layout.SimpleSpinnerItem))

                //  {


                //      SqlConnection con = new SqlConnection(str);
                //      if (con.State == ConnectionState.Closed)
                //          con.Open();

                //      // //con.;
                //      SqlCommand cmd = new SqlCommand(query);
                //      // //SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                //      // //listens for extra updates to table
                //      // //SqlCommandBuilder sqlBuilder = new SqlCommandBuilder(adapter);

                //      cmd = new SqlCommand(query, con);
                //      SqlDataReader sqlReader = cmd.ExecuteReader();
                //      while (sqlReader.Read())
                //      {
                //          adapter.Add("" + sqlReader["column_name"].ToString() + "");
                //      }




                //      // //DataTable dt = new DataTable();
                //      //// adapter.Fill(dt);
                //      //// foreach(var item in dt)
                //      Trip.Adapter = adapter;
                //      // //TripDropdown.DisplayMember = "GameType";

                //      // con.Close();
                //  }
            };






        }
    }
}